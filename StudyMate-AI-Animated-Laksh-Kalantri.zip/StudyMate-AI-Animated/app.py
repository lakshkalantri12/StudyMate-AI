from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

def clean_text(text):
    return " ".join(text.strip().split())

def keywords_from(text):
    stop = {"about","there","their","which","would","could","should","these","those","because","where","while","with","from","into","your","this","that"}
    found = []
    for raw in text.split():
        word = raw.strip(".,!?():;\"'[]{}").lower()
        if len(word) >= 6 and word not in stop and word not in found:
            found.append(word)
    return found[:6] or ["main idea", "definition", "example"]

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/generate", methods=["POST"])
def generate():
    data = request.get_json(silent=True) or {}
    text = clean_text(data.get("text", ""))
    mode = data.get("mode", "explain")
    if not text:
        return jsonify({"title":"Please add study material","result":"Enter a topic or paste your notes first."}), 400

    source = text[:1200]
    keys = keywords_from(text)
    keyline = ", ".join(keys)

    if mode == "summarize":
        title = "📝 Quick Summary"
        result = f"""YOUR MATERIAL
{source}

QUICK SUMMARY
• Focus on the central idea of the material.
• Separate the topic into smaller concepts.
• Connect important terms with definitions or examples.

KEYWORDS
{keyline}

REVISION TIP
Try explaining the topic in your own words without looking at the original notes."""
    elif mode == "quiz":
        title = "❓ Practice Quiz"
        result = f"""PRACTICE QUESTIONS

1. What is the main idea of this topic?
2. Explain the topic in your own words.
3. What are the most important terms or concepts?
4. Give one example connected to the topic.
5. Why is this topic important?
6. Write a short answer using these keywords: {keyline}.

SELF-CHECK
Answer first without looking at your notes, then compare."""
    elif mode == "revision":
        title = "🧠 Revision Sheet"
        result = f"""TOPIC / NOTES
{source}

KEYWORDS
• """ + "\n• ".join(keys) + """

REVISION CHECKLIST
□ I know the main idea.
□ I can define the important terms.
□ I can give an example.
□ I can explain the topic without reading my notes.

LAST-MINUTE TIP
Review the keywords, then explain the full topic aloud in simple words."""
    else:
        title = "📖 Simple Explanation"
        result = f"""YOUR TOPIC / NOTES
{source}

HOW TO UNDERSTAND IT
1. Find the main idea.
2. Break it into smaller points.
3. Understand each important term.
4. Connect each point with an example.
5. Explain it again in your own words.

IMPORTANT TERMS TO REVIEW
{keyline}

STUDY TIP
If you can explain the topic simply without looking at the notes, you probably understand the core idea."""

    return jsonify({"title": title, "result": result})

if __name__ == "__main__":
    app.run(debug=True)
