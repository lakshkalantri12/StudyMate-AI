# StudyMate AI — Animated Edition

Created by Laksh Kalantri.

## Included
- Modern animated responsive interface
- Particle background
- Moving glow effects
- Mouse glow and click ripple
- Smooth page and result animations
- Explain mode
- Summarize mode
- Quiz mode
- Revision mode
- Python Flask backend

## Run on Windows
1. Extract the ZIP.
2. Open the extracted `StudyMate-AI-Animated` folder.
3. Open Command Prompt or PowerShell in that folder.
4. Run:
   pip install -r requirements.txt
5. Run:
   python app.py
6. Open the address shown in the terminal (normally http://127.0.0.1:5000).

## Note
This edition is a complete runnable starter project. Its study-material generator is currently local/rule-based, so no external AI API or API key is required. A real AI model can be integrated later.
